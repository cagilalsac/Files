﻿#nullable disable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Records.Bases;

namespace DataAccess.Entities
{

    public class Role : Record
    {
        //Way 1
        //[Required]
        //public String Name { get; set; } = null!;


        //Way 2
        public String Name { get; set; } = null!;


        //public List<User> User { get; set; }


        //Another alternative
        public ICollection<User> Users { get; set; }
    }
}
