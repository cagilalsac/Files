﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using DataAccess.Records.Bases;

namespace DataAccess.Entities
{
    public class Game :  Record  //DataAccess.Records.Bases Record
    {
        //private int _id; // field

        //public void SetId(int id) // behaviors, setter
        //{
        //    _id = id;
        //}

        //public int GetId() // behaviors, getter
        //{
        //    return _id;
        //}

     

        [Required] //only affects next line
        [StringLength(100)]  //we can write maximum char that can be entered
        public string Name { get; set; }
        public DateTime? PublishDate { get; set; } //not required


        //for example we don't know when GTA6's publish date, so its nullable
        public decimal? TotalSalesPrice { get; set; } // double, float, not required

        public int? PublisherId { get; set; }

        public Publisher Publisher { get; set; }
        public List<UserGame> userGames { get; set; }

        /*
         also can be used as

        Nullable<decimal>
         
         */
    }
}
