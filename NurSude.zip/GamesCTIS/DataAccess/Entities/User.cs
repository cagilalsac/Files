﻿using System.ComponentModel.DataAnnotations;
using DataAccess.Records.Bases;

namespace DataAccess.Entities
{
    public class User : Record
    {
        [Required]
        [StringLength(100)]

      
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; }
        //public Statuses Status { get; set; } // junior, senior, master

        public Statuses Status { get; set; }

        public int RoleId { get; set; }

        public Role Role { get; set; }

        public List<UserGame> userGames { get; set; }
    }
}
