﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Entities;

namespace DataAccess.Contexts
{
    public class Db : DbContext
    {
        public DbSet<Game> Games { get; set; }

        public DbSet<Publisher> Publisher { get; set; }

        public DbSet<User> Users { get; set; }

        public DbSet<Role> Roles { get; set; }

        public DbSet<UserGame> UserGames { get; set; }

    }
}
