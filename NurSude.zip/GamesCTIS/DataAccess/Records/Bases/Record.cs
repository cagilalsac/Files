﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Entities;

#nullable disable
namespace DataAccess.Records.Bases
{
    public class Record
    {


        public int Id { get; set; } //is required

        // public int? Id { get; set; }   -> it means this can be null.
        public string Guid { get; set; }

        //if we didnt put nullable , its is required
        // public string? Guid { get; set; }  //not required



        /*
            Use reference types without question marks, use question marks with only value types
           
        
        
            if you put #nullable disable on the top of your page
            you dont have to put question marks



         */
    }
}
